<?php 
$pag = 'livros';
 ?>
<a onclick="inserir()" type="button" class="btn btn-primary"><span class="fa fa-plus"></span>Cadastrar</a>



<li class="dropdown head-dpdn2" style="display: inline-block;">		
		<a href="#" data-toggle="dropdown"  class="btn btn-danger dropdown-toggle" id="btn-deletar" style="display:none"><span class="fa fa-trash-o"></span> Deletar</a>

			<div class="row">
						<div class="col-md-6">							
								<label>titulo</label>
								<input type="text" class="form-control" id="nome" name="nome" placeholder="buscar titulo" required>							
						</div>

						<div class="col-md-6">							
								<label>Categoria</label>
								<input type="email" class="form-control" id="email" name="email" placeholder="Seu Email"  required>							
						</div>

						
					</div>


					<div class="row">

						<div class="col-md-6">							
								<label>Telefone</label>
								<input type="text" class="form-control" id="telefone" name="telefone" placeholder="Seu Telefone" required>							
						</div>
						

						<div class="col-md-6">							
								<label>Nível</label>
								<select class="form-control" name="nivel" id="nivel">
								  <option>Administrador</option>
								  <option>Comum</option>
								</select>							
						</div>


						
					</div>

					<div class="row">

						<div class="col-md-12">							
								<label>Endereço</label>
								<input type="text" class="form-control" id="endereco" name="endereco" placeholder="Seu Endereço" >							
						</div>
					</div>

					<table class="table table-hover" id="tabela">
	<thead> 
	


					
