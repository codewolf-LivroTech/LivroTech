
<?php 
$pag = 'livros';
?>
<a onclick="inserir()" type="button" class="btn btn-primary"><span class="fa fa-book"></span>Cadastrar</a>



<li class="dropdown head-dpdn2" style="display: inline-block;">		
	<a href="#" data-toggle="dropdown"  class="btn btn-danger dropdown-toggle" id="btn-deletar" style="display:none"><span class="fa fa-trash-o"></span> Deletar</a>



	<li class="dropdown head-dpdn2" style="display: inline-block;">		
		<a href="#" data-toggle="dropdown"  class="btn btn-danger dropdown-toggle" id="btn-deletar" style="display:none"><span class="fa fa-trash-o"></span> Deletar</a>

		<ul class="dropdown-menu">
			<li>
				<div class="notification_desc2">
					<p>Excluir Selecionados? <a href="#" onclick="deletarSel()"><span class="text-danger">Sim</span></a></p>
				</div>
			</li>										
		</ul>
	</li>

	<div class="bs-example widget-shadow" style="padding:15px" id="listar">

	</div>

<input type="hidden" id="ids">

	<!-- Modal Perfil -->
	<div class="modal fade" id="modalForm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title" id="exampleModalLabel"><span id="titulo_inserir"></span></h4>
					<button id="btn-fechar" type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin-top: -25px">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form id="form">
					<div class="modal-body">


						<div class="row">
							<div class="col-md-6">							
								<label>Titulos</label>
								<input type="text" class="form-control" id="nome" name="nome" placeholder="Seu titulo" required>							
							</div>

							<div class="col-md-6">							
								<label>Categoria</label>
								<input type="text" class="form-control" id="email" name="nome" placeholder="Sua categoria"  required>							
							</div>


						</div>


						<div class="row">

							<div class="col-md-6">							
								<label>Quantidade</label>
								<input type="text" class="form-control" id="nome" name="telefone" placeholder="Quantidade" required>							
							</div>


							<div class="col-md-6">							
								<label>Autor</label>
								<input type="text" 
								select class="form-control" name="nome" placeholder="Seu autor">
							</select>							
						</div>


						
					</div>

					<div class="row">

						<div class="col-md-12">							
							<label>Prazo</label>
							<input type="text" class="form-control" id="endereco" name="endereco" placeholder="Prazo de entrega" >							
						</div>
					</div>

					


					


					<input type="hidden" class="form-control" id="id" name="id">					

					<br>
					<small><div id="mensagem" align="center"></div></small>
				</div>
				<div class="modal-footer">       
					<button type="submit" class="btn btn-primary">Salvar</button>
				</div>
			</form>
		</div>
	</div>
</div>





<!-- Modal Dados -->
<div class="modal fade" id="modalDados" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="exampleModalLabel"><span id="titulo_dados"></span></h4>
				<button id="btn-fechar-dados" type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin-top: -25px">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			
			<div class="modal-body">
				<div class="row" style="margin-top: 0px">
					<div class="col-md-6" style="margin-bottom: 5px">
						<span><b>Titulo: </b></span><span id="titulo_dados"></span>
					</div>

					
					<div class="col-md-8" style="margin-bottom: 5px">
						<span><b>Email: </b></span><span id="email_dados"></span>
					</div>

					

					<div class="col-md-4" style="margin-bottom: 5px">
						<span><b>Senha: </b></span><span id="senha_dados"></span>
					</div>

					<div class="col-md-6" style="margin-bottom: 5px">
						<span><b>Nível: </b></span><span id="nivel_dados"></span>
					</div>

					<div class="col-md-6" style="margin-bottom: 5px">
						<span><b>Ativo: </b></span><span id="ativo_dados"></span>
					</div>

					<div class="col-md-6" style="margin-bottom: 5px">
						<span><b>Data Cadastro: </b></span><span id="data_dados"></span>
					</div>

					<div class="col-md-12" style="margin-bottom: 5px">
						<span><b>Endereço: </b></span><span id="endereco_dados"></span>
					</div>

					<div class="col-md-12" style="margin-bottom: 5px">
						<div align="center"><img src="" id="foto_dados" width="200px"></div>
					</div>
				</div>
			</div>

		</div>
	</div>
</div>



<script type="text/javascript">var pag = "<?=$pag?>"</script>
<script src="js/ajax.js"></script>

